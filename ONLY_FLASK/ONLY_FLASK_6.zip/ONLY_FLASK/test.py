import requests

print("/api/v2/jobs")

print("__get__")
response = requests.get("http://127.0.0.1:5000/api/v2/jobs")
print(response.json())

print("__post__")
response = requests.post("http://127.0.0.1:5000/api/v2/jobs", json={
    "team_leader": 3,
    "job": "В отдельном модуле jobs_resource.py создайте два класса: JobsResource и JobsListResource для получения "
           "доступа к действиям с одной работой и со всеми работами.",
    "work_size": 54,
    "collaborators": "1, 2, 3, 4",
    "is_finished": False
})
print(response.json())

print()
print("/api/v2/jobs/<int:jobs_id>")

print("__get__")
response = requests.get("http://127.0.0.1:5000/api/v2/jobs/13")
print(response.json())


print("__post__")
response = requests.post("http://127.0.0.1:5000/api/v2/jobs/13", json={
    "team_leader": 1,
    "job": "новое",
    "work_size": 123,
    "collaborators": "4, 3, 2, 1",
    "is_finished": True
})
print(response.json())


print("__delete__")
response = requests.delete("http://127.0.0.1:5000/api/v2/jobs/13")
print(response.json())

