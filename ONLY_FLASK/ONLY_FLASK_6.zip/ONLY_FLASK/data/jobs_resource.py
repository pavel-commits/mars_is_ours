from flask import jsonify
from flask_restful import abort, Resource
from .req_parsers.jobs_parser import get_parser
from .db_session import create_session
from .jobs import Jobs


def abort_if_job_not_found(jobs_id):
    db_sess = create_session()
    jobs = db_sess.query(Jobs).get(jobs_id)
    if not jobs:
        abort(404, message="Not found")


class JobsResource(Resource):
    def get(self, jobs_id):
        abort_if_job_not_found(jobs_id)

        db_sess = create_session()
        jobs = db_sess.query(Jobs).get(jobs_id)
        return jsonify({
            "jobs": jobs.to_dict(only=("team_leader",
                                       "job",
                                       "work_size",
                                       "collaborators",
                                       "start_date",
                                       "end_date",
                                       "is_finished"))})

    def post(self, jobs_id):
        parser = get_parser()
        args = parser.parse_args()

        abort_if_job_not_found(jobs_id)
        db_sess = create_session()
        jobs = db_sess.query(Jobs).get(jobs_id)

        jobs.team_leader = args.get("team_leader")
        jobs.job = args.get("job")
        jobs.work_size = args.get("work_size")
        jobs.collaborators = args.get("collaborators")
        jobs.is_finished = args.get("is_finished")

        db_sess.commit()
        return jsonify({"success": "OK"})

    def delete(self, jobs_id):
        abort_if_job_not_found(jobs_id)
        db_sess = create_session()
        jobs = db_sess.query(Jobs).get(jobs_id)
        db_sess.delete(jobs)
        db_sess.commit()
        return jsonify({"success": "OK"})


class JobsListResource(Resource):
    def get(self):
        db_sess = create_session()
        jobs = db_sess.query(Jobs).all()
        return jsonify({
            "jobs": [i.to_dict(only=("team_leader",
                                     "job",
                                     "work_size",
                                     "collaborators",
                                     "start_date",
                                     "end_date",
                                     "is_finished"))
                     for i in jobs]})

    def post(self):
        parser = get_parser()
        args = parser.parse_args()

        db_sess = create_session()

        jobs = Jobs()
        jobs.team_leader = args.get("team_leader")
        jobs.job = args.get("job")
        jobs.work_size = args.get("work_size")
        jobs.collaborators = args.get("collaborators")
        jobs.is_finished = args.get("is_finished")
        db_sess.add(jobs)
        db_sess.commit()
        return jsonify({"success": "OK"})