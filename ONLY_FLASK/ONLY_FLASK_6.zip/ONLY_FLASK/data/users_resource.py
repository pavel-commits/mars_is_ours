from flask import jsonify
from flask_restful import abort, Resource
from .req_parsers.users_parser import get_parser
from .db_session import create_session
from .users import User


def abort_if_user_not_found(user_id):
    db_sess = create_session()
    user = db_sess.query(User).get(user_id)
    if not user:
        abort(404, message="Not found")


class UsersResource(Resource):
    def get(self, user_id):
        abort_if_user_not_found(user_id)
        db_sess = create_session()
        user = db_sess.query(User).get(user_id)

        return jsonify({
            "users": [user.to_dict(only=("id",
                                         "surname",
                                         "name",
                                         "age",
                                         "position",
                                         "speciality",
                                         "address",
                                         "email",
                                         "hashed_password",
                                         "modified_date"))]})

    def delete(self, user_id):
        abort_if_user_not_found(user_id)
        db_sess = create_session()
        user = db_sess.query(User).get(user_id)

        db_sess.delete(user)
        db_sess.commit()

        return jsonify({"success": "OK"})


class UsersListResource(Resource):
    def get(self):
        db_sess = create_session()
        user = db_sess.query(User).all()
        return jsonify({
            "users": [u.to_dict(only=("id",
                                      "surname",
                                      "name",
                                      "age",
                                      "position",
                                      "speciality",
                                      "address",
                                      "email",
                                      "hashed_password",
                                      "modified_date"))
                      for u in user]})

    def post(self):
        parser = get_parser()
        args = parser.parse_args()
        db_sess = create_session()
        email = args.get("email")

        if db_sess.query(User).filter(User.email == email).first():
            return jsonify({
                "error": f"Email '{email}' is already registered"
            })

        user = User()
        user.surname = args.get("surname")
        user.name = args.get("name")
        user.age = args.get("age")
        user.position = args.get("position")
        user.speciality = args.get("speciality")
        user.address = args.get("address")
        user.email = email
        user.set_password(args.get("password"))

        db_sess.add(user)
        db_sess.commit()

        return jsonify({
            "success": "OK"
        })
