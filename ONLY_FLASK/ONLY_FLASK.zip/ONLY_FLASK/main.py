# flask
from flask import Flask
from flask import render_template
from flask import redirect

# data
from data.db_session import global_init
from data.db_session import create_session
from data.users import User
from data.jobs import Jobs
from data.departments import Department

# forms
from forms.user import RegisterForm

app = Flask(__name__)
app.config["SECRET_KEY"] = "Aliexlask"


@app.route("/")
def index():
    db_sess = create_session()
    actions = db_sess.query(Jobs).all()

    return render_template("index.html", title="Рабочий журнал", actions=actions)


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="Passwords don't match")
        db_sess = create_session()
        if db_sess.query(User).filter(User.email == form.email.data).first():
            return render_template('register.html', title='Регистрация',
                                   form=form,
                                   message="This email is already registered")
        user = User()
        user.surname = form.surname.data
        user.name = form.name.data
        user.age = form.age.data
        user.position = form.position.data
        user.speciality = form.speciality.data
        user.address = form.address.data
        user.email = form.email.data
        user.set_password(form.password.data)

        db_sess.add(user)
        db_sess.commit()
        return redirect('/login')
    return render_template('register.html', title='Регистрация', form=form)


@app.route('/login')
def login():
    return redirect("/")


if __name__ == '__main__':
    global_init("mars_explorer.db")
    app.run()