from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField, IntegerField
from wtforms import BooleanField, SubmitField
from wtforms.validators import DataRequired


class JobForm(FlaskForm):
    job = StringField("Job title", validators=[DataRequired()])
    team_leader = IntegerField("Team Leader ID", validators=[DataRequired()])
    work_size = IntegerField("Work size (number of hours)", validators=[DataRequired()])
    collaborators = StringField("collaborators", validators=[DataRequired()])
    is_finished = BooleanField("Is job finished?")

    submit = SubmitField("Submit")