import time

import requests

# __/users__
print("/users")
# "__get__"
response = requests.get("http://127.0.0.1:5000/api/v2/users")
print(response.json())

# "__post__"
response = requests.post("http://127.0.0.1:5000/api/v2/users", json={
    "surname": "LAST",
    "name": "TEST_USER",
    "age": 19,
    "position": "porter",
    "speciality": "stage",
    "address": "module_4",
    "email": "last_test_user@mail.ru",
    "password": "1234567890"
})
print(response.json())

# "__post__" --> {"error": "Email 'last_test_user@mail.ru' is already registered"}
response = requests.post("http://127.0.0.1:5000/api/v2/users", json={
    "surname": "New_last",
    "name": "TEST_USER",
    "age": 12,
    "position": "capitan",
    "speciality": "it",
    "address": "module_1",
    "email": "last_test_user@mail.ru",
    "password": "qwerty"
})
print(response.json())

# "__post__" age: type=int & surname: missed required
response = requests.post("http://127.0.0.1:5000/api/v2/users", json={
    "name": "TEST_USER",
    "age": "12",
    "position": "capitan",
    "speciality": "it",
    "address": "module_1",
    "email": "last_test_user@yandex.ru",
    "password": "qwerty"
})
print(response.json())

print()
# __/users/<int:user_id>__
print("/users/<int:user_id>")
# "__get__"
response = requests.get("http://127.0.0.1:5000/api/v2/users/1")
print(response.json())

# "__get__" --> {'message': 'Not found'}
response = requests.get("http://127.0.0.1:5000/api/v2/users/999")
print(response.json())

# "__delete__"
response = requests.delete("http://127.0.0.1:5000/api/v2/users/10")
print(response.json())

# "__delete__" --> {'message': 'Not found'}
response = requests.delete("http://127.0.0.1:5000/api/v2/users/999")
print(response.json())
